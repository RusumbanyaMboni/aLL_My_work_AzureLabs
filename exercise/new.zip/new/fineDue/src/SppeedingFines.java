public class SppeedingFines extends fine{
    public SppeedingFines(String name, int speed) {
        super(name, speed);
    }

    public prinFine(){
        super();

    }
}
