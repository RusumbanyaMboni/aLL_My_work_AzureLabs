public interface iFine {
    public void printFine();
}
