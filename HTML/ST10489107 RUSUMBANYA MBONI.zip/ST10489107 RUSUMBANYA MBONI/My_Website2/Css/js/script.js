

console.log("Website loaded successfully!");
